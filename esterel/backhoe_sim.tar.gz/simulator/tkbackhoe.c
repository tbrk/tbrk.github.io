/*************************************************************
 * 20051020 T.Bourke (UNSW CSE/NICTA)
 *    Glue code between compiled backhoe control software
 *    and the Tcl/Tk generator. These basics are drawn
 *    directly from the INRIA/CMA wristwatch example.
 *
 * $Id: tkbackhoe.c 7 2006-02-07 04:19:50Z tbourke $
 *
 */

#include "tcl.h"
#include "tk.h"

static Tcl_Interp* ginterp;

/* see Tcl_CreateCommand */
typedef struct Tcl_GenericCommand {
	char* cmdName;
	Tcl_CmdProc* proc;
	ClientData clientData;
	Tcl_CmdDeleteProc* deleteProc;
} Tcl_GenericCommand ;

/*************************************************************
 * Output functions
 */
void BACKHOE_O_ALARM_LAMP(int set)
{
	Tcl_SetVar2(ginterp, "Status", "Alarm", set?"1":"0", TCL_GLOBAL_ONLY);
}

void BACKHOE_O_DONE_LAMP(int set)
{
	Tcl_SetVar2(ginterp, "Status", "Done", set?"1":"0", TCL_GLOBAL_ONLY);
}

void BACKHOE_O_CANCEL_LAMP(int set)
{
	Tcl_SetVar2(ginterp, "Status", "Cancelled", set?"1":"0", TCL_GLOBAL_ONLY);
}

void BACKHOE_O_BOOM_PUSH(void)
{
	Tcl_SetVar2(ginterp, "Status", "boomdir", "1", TCL_GLOBAL_ONLY);
}

void BACKHOE_O_BOOM_PULL(void)
{
	Tcl_SetVar2(ginterp, "Status", "boomdir", "-1", TCL_GLOBAL_ONLY);
}

void BACKHOE_O_BOOM_DRIVE(void)
{
	Tcl_SetVar2(ginterp, "Status", "boominc", "1", TCL_GLOBAL_ONLY);
}

void BACKHOE_O_STICK_PUSH(void)
{
	Tcl_SetVar2(ginterp, "Status", "stickdir", "1", TCL_GLOBAL_ONLY);
}

void BACKHOE_O_STICK_PULL(void)
{
	Tcl_SetVar2(ginterp, "Status", "stickdir", "-1", TCL_GLOBAL_ONLY);
}

void BACKHOE_O_STICK_DRIVE(void)
{
	Tcl_SetVar2(ginterp, "Status", "stickinc", "1", TCL_GLOBAL_ONLY);
}

void BACKHOE_O_BUCKET_PUSH(void)
{
	Tcl_SetVar2(ginterp, "Status", "bucketdir", "1", TCL_GLOBAL_ONLY);
}

void BACKHOE_O_BUCKET_PULL(void)
{
	Tcl_SetVar2(ginterp, "Status", "bucketdir", "-1", TCL_GLOBAL_ONLY);
}

void BACKHOE_O_BUCKET_DRIVE(void)
{
	Tcl_SetVar2(ginterp, "Status", "bucketinc", "1", TCL_GLOBAL_ONLY);
}

void BACKHOE_O_LEGS_RAISE(void)
{
	Tcl_SetVar2(ginterp, "Status", "legsdir", "-1", TCL_GLOBAL_ONLY);
	Tcl_SetVar2(ginterp, "Status", "legsinc", "1", TCL_GLOBAL_ONLY);
}

void BACKHOE_O_LEGS_LOWER(void)
{
	Tcl_SetVar2(ginterp, "Status", "legsdir", "1", TCL_GLOBAL_ONLY);
	Tcl_SetVar2(ginterp, "Status", "legsinc", "1", TCL_GLOBAL_ONLY);
}

void BACKHOE_O_LEGS_STOP(void)
{
	Tcl_SetVar2(ginterp, "Status", "legsinc", "0", TCL_GLOBAL_ONLY);
}

/*************************************************************
 * Input functions
 */

extern int BACKHOE();
extern void BACKHOE_I_BOOM_OUT();
extern void BACKHOE_I_BOOM_IN();
extern void BACKHOE_I_STICK_OUT();
extern void BACKHOE_I_STICK_IN();
extern void BACKHOE_I_BUCKET_OUT();
extern void BACKHOE_I_BUCKET_IN();
extern void BACKHOE_I_LEGS_OUT();
extern void BACKHOE_I_LEGS_IN();
extern void BACKHOE_I_STOP_BUTTON();
extern void BACKHOE_I_EXTEND_BUTTON();
extern void BACKHOE_I_RETRACT_BUTTON();
extern void BACKHOE_I_SECOND();

int Tcl_BOOM_OUT(ClientData data, Tcl_Interp* interp, int argc, char** argv)
{
	BACKHOE_I_BOOM_OUT();
	return TCL_OK;
}

int Tcl_BOOM_IN(ClientData data, Tcl_Interp* interp, int argc, char** argv)
{
	BACKHOE_I_BOOM_IN();
	return TCL_OK;
}

int Tcl_STICK_OUT(ClientData data, Tcl_Interp* interp, int argc, char** argv)
{
	BACKHOE_I_STICK_OUT();
	return TCL_OK;
}

int Tcl_STICK_IN(ClientData data, Tcl_Interp* interp, int argc, char** argv)
{
	BACKHOE_I_STICK_IN();
	return TCL_OK;
}

int Tcl_BUCKET_OUT(ClientData data, Tcl_Interp* interp, int argc, char** argv)
{
	BACKHOE_I_BUCKET_OUT();
	return TCL_OK;
}

int Tcl_BUCKET_IN(ClientData data, Tcl_Interp* interp, int argc, char** argv)
{
	BACKHOE_I_BUCKET_IN();
	return TCL_OK;
}

int Tcl_LEGS_OUT(ClientData data, Tcl_Interp* interp, int argc, char** argv)
{
	BACKHOE_I_LEGS_OUT();
	return TCL_OK;
}

int Tcl_LEGS_IN(ClientData data, Tcl_Interp* interp, int argc, char** argv)
{
	BACKHOE_I_LEGS_IN();
	return TCL_OK;
}

int Tcl_STOP_BUTTON(ClientData data, Tcl_Interp* interp, int argc, char** argv)
{
	BACKHOE_I_STOP_BUTTON();
	return TCL_OK;
}

int Tcl_EXTEND_BUTTON(ClientData data, Tcl_Interp* interp, int argc, char** argv)
{
	BACKHOE_I_EXTEND_BUTTON();
	return TCL_OK;
}

int Tcl_RETRACT_BUTTON(ClientData data, Tcl_Interp* interp, int argc, char** argv)
{
	BACKHOE_I_RETRACT_BUTTON();
	return TCL_OK;
}

int Tcl_SECOND(ClientData data, Tcl_Interp* interp, int argc, char** argv)
{
	BACKHOE_I_SECOND();
	return TCL_OK;
}

int Tcl_BACKHOE(ClientData data, Tcl_Interp* interp, int argc, char** argv)
{
	BACKHOE();
	return TCL_OK;
}

int Tcl_BACKHOE_reset(ClientData data, Tcl_Interp* interp, int argc, char** argv)
{
	BACKHOE_reset();
	return TCL_OK;
}

Tcl_GenericCommand input_commands[] = {
	{
	"BACKHOE",
	(Tcl_CmdProc*)Tcl_BACKHOE,
	(ClientData)NULL,
	(Tcl_CmdDeleteProc *)NULL
	},
	{
	"BACKHOE_reset",
	(Tcl_CmdProc*)Tcl_BACKHOE_reset,
	(ClientData)NULL,
	(Tcl_CmdDeleteProc *)NULL
	},
	{
	"BOOM_OUT",
	(Tcl_CmdProc*)Tcl_BOOM_OUT,
	(ClientData)NULL,
	(Tcl_CmdDeleteProc *)NULL
	},
	{
	"BOOM_IN",
	(Tcl_CmdProc*)Tcl_BOOM_IN,
	(ClientData)NULL,
	(Tcl_CmdDeleteProc *)NULL
	},
	{
	"STICK_OUT",
	(Tcl_CmdProc*)Tcl_STICK_OUT,
	(ClientData)NULL,
	(Tcl_CmdDeleteProc *)NULL
	},
	{
	"STICK_IN",
	(Tcl_CmdProc*)Tcl_STICK_IN,
	(ClientData)NULL,
	(Tcl_CmdDeleteProc *)NULL
	},
	{
	"BUCKET_OUT",
	(Tcl_CmdProc*)Tcl_BUCKET_OUT,
	(ClientData)NULL,
	(Tcl_CmdDeleteProc *)NULL
	},
	{
	"BUCKET_IN",
	(Tcl_CmdProc*)Tcl_BUCKET_IN,
	(ClientData)NULL,
	(Tcl_CmdDeleteProc *)NULL
	},
	{
	"LEGS_OUT",
	(Tcl_CmdProc*)Tcl_LEGS_OUT,
	(ClientData)NULL,
	(Tcl_CmdDeleteProc *)NULL
	},
	{
	"LEGS_IN",
	(Tcl_CmdProc*)Tcl_LEGS_IN,
	(ClientData)NULL,
	(Tcl_CmdDeleteProc *)NULL
	},
	{
	"STOP_BUTTON",
	(Tcl_CmdProc*)Tcl_STOP_BUTTON,
	(ClientData)NULL,
	(Tcl_CmdDeleteProc *)NULL
	},
	{
	"EXTEND_BUTTON",
	(Tcl_CmdProc*)Tcl_EXTEND_BUTTON,
	(ClientData)NULL,
	(Tcl_CmdDeleteProc *)NULL
	},
	{
	"RETRACT_BUTTON",
	(Tcl_CmdProc*)Tcl_RETRACT_BUTTON,
	(ClientData)NULL,
	(Tcl_CmdDeleteProc *)NULL
	},
	{
	"SECOND",
	(Tcl_CmdProc*)Tcl_SECOND,
	(ClientData)NULL,
	(Tcl_CmdDeleteProc *)NULL
	},
	{
	NULL,
	(Tcl_CmdProc*)NULL,
	(ClientData)NULL,
	(Tcl_CmdDeleteProc *)NULL
	}
};


/*************************************************************
 * Initialization
 */
int Tcl_AppInit(Tcl_Interp* interp)
{
	int i=0;
	
	if (Tcl_Init(interp) == TCL_ERROR) {
		return TCL_ERROR;
	}

	if (Tk_Init(interp) == TCL_ERROR) {
		return TCL_ERROR;
	}

	ginterp = interp;

	while (input_commands[i].cmdName != (char*)NULL) {
		Tcl_CreateCommand(interp,
				  input_commands[i].cmdName,
				  input_commands[i].proc,
				  input_commands[i].clientData,
				  input_commands[i].deleteProc);
		i++;
	}

	Tcl_EvalFile(ginterp, "backhoe.tcl");

	return TCL_OK;
}

int main(int argc, char* argv[])
{
	Tcl_Main(argc, argv, Tcl_AppInit);
}

