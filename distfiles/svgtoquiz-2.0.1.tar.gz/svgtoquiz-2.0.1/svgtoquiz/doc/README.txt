svgtoquiz was written by Timothy Bourke <timbob@bigpond.com>.

Use is governed by the terms in the file LICENSE.

Additional Contributions
------------------------
Patrick Kenny	    While testing found several unicode bugs and unexpected
		    dependencies and suggested the -only-vice-versa option.
Tobias Hall	    Spotted bug with Serbia in Blank_map_of_Europe.svg.
Paul Chivers	    Bugs, feedback and patches for using the script on Windows.

