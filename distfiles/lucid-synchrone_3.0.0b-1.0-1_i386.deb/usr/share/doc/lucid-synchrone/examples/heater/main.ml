(* $Id: main.ml,v 1.2 2006/12/29 17:19:30 pouzet Exp $ *)
open Graphics
open Sampling;;

Printf.printf
 "Inputs: 
    - expected_temp (expected temperature)
    - actual_temp (actual temperature)
    - restart (restart the heater)
    - on_light (turns on the light)
  Outputs: 
    - open_light (the command is turned on)
    - open_gas (the same for the gas)

  Press the following key to control it:
    - P: increase expected_temp by 1
    - M: decrease expected_temp by 1
    - E: increase actual_temp by 1
    - Z: decrease actual_temp by 1
    - R: restarts the controler
    - L: on_light is on\n";
flush stdout;
open_graph "";
sim2chro [Key_pressed] 1.0 0.1 System.step;
exit 0;;
