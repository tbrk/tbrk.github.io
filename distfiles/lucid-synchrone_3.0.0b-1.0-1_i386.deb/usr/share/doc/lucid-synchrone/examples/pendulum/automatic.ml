(* simulation file *)
open Controller
let step, reset =
   let _m1006 = ref `Snil_ in
   let step = fun _x1004 _x1005 -> automatic true _x1004 _x1005 false _m1006 in
   let reset = fun () -> _m1006 := `Snil_ in
   step, reset
