(* $Id: pendulum_data.ml,v 1.2 2006/04/06 11:00:52 pouzet Exp $ *)
open Graphics;;

type pendulum =
    { x0: float;
      y0: float;
      x: float;
      y: float};;


let make_pend x0 y0 x y =
  { x0 = x0; y0 = y0; x = x; y = y };;

let get_cursor () =
  let cx,cy = mouse_pos() in
  float cx /. 10.0,
  float cy /. 10.0;;

let button_down () = button_down ()

let mouse () =
  let status = wait_next_event [Poll;Button_down;Key_pressed] in
  let cx = status.mouse_x in
  let cy = status.mouse_y in
  let cx = float cx /. 10.0 in
  let cy = float cy /. 10.0 in
  let bd = status.button in
  cx, cy, bd

let draw_pendulum color { x0 = x0; y0 = y0; x = x; y = y } = 
  let x0 = truncate (10.0 *. x0) in
  let x  = truncate (10.0 *. x)  in
  let y0 = truncate (10.0 *. y0) in
  let y  = truncate (10.0 *. y)  in
  set_color color;
  moveto x0 y0;
  lineto x y;
  draw_circle x y 5;;

(* p is the current pendulum and pp is the previous one *)
let draw_pendulum p pp =
  draw_pendulum background pp;
  draw_pendulum foreground p;
  synchronize ();;

(* initialization *)
open_graph "";;
auto_synchronize false;;
set_line_width 4;;

