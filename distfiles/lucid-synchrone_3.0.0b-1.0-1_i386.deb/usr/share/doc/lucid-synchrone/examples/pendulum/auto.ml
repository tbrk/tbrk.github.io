(* simulation file *)
open Graphics
open Automatic
open Sampling;;

(* initialization *)
(*
open_graph "";;
auto_synchronize false;;
set_line_width 4;;
*)
(*grun [Button_down; Button_up] 1.0 0.01 Automatic.step;*)
sim2chro [Button_down; Button_up] 1.0 0.01 Automatic.step;
exit 0;;
