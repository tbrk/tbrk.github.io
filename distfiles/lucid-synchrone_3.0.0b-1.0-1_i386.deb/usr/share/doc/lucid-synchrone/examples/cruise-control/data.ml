(* $Id: data.ml,v 1.4 2006/04/12 15:48:44 delaval Exp $ *)
open Graphics

type 'a option = None | Some of 'a

let keyboard () =
  let status = wait_next_event [Poll] in
  if status.keypressed then 
    let key = read_key () in
    Some(key)
  else None;;

open_graph "";;
