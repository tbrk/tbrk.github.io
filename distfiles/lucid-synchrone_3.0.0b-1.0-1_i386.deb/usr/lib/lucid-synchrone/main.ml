(* simulation file *)
open Chrono
let step, reset =
   let _m857 = ref `Snil_ in
   let step = fun _x856 -> main true true _x856 false _m857 in
   let reset = fun () -> _m857 := `Snil_ in
   step, reset
let main _ = step ();;
(* simulation loop: sampled on 10 Hz *)
(* compiles with -custom unix.cma    *)
let periodic() =
   let _x = Unix.setitimer Unix.ITIMER_REAL
     {Unix.it_interval = 0.100000 ; Unix.it_value = 1.0 }
   in Sys.set_signal Sys.sigalrm (Sys.Signal_handle main);
   while true do Unix.sleep 1 done;;

 periodic();exit(0)
