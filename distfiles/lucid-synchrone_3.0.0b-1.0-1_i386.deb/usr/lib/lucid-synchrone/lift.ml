type ('a2, 'a1) _state_145 = {mutable _init112:'a2; mutable _pre108:'a1;}
and ('a5, 'a4, 'a3, 'a2, 'a1)
      _state_152 = {mutable _init133:'a5;
                    mutable _init115:'a4;
                    mutable _pre130:'a3;
                    mutable _init122:'a2; mutable _pre119:'a1;}

let lift = fun _cl47 _48__f _49__i _50__input _109 _self_144 ->
             let _self_144 = match !_self_144 with
                               | `St_147(_self_144) -> _self_144
                               | _ ->
                                   let _146 = {_init112 = true;
                                               _pre108 = Obj.magic ()} in
                                   _self_144 := `St_147(_146); _146
                                in
             let _111 = ref false in
             let __last107 = ref (Obj.magic ()) in
             let _138 = ref (Obj.magic (), Obj.magic ()) in
             (if _cl47 then
               (_111 := (or) _109 _self_144._init112;
                __last107 :=
                  (if !_111 then _48__f.S.init _49__i else _self_144._pre108);
                _138 := _48__f.S.step (!__last107, _50__input)));
             (let (_51__o, _52__s) = !_138 in
              (if _cl47 then _self_144._pre108 <- _52__s);
              _self_144._init112 <- (&) !_111 (not _cl47); _51__o)

let double_lift = fun
                    _cl100
                    _102__f
                    (_103__i1, _104__i2)
                    _105__input1 _106__input2 _110 _self_151 ->
                    let _self_151 = match !_self_151 with
                                      | `St_154(_self_151) -> _self_151
                                      | _ ->
                                          let _153 = {_init133 = true;
                                                      _init115 = true;
                                                      _pre130 = Obj.magic ();
                                                      _init122 = true;
                                                      _pre119 = Obj.magic ()} in
                                          _self_151 := `St_154(_153); _153
                                       in
                    let __last118 = ref (Obj.magic ()) in
                    let _132 = ref false in
                    let _114 = ref false in
                    let __last129 = ref (Obj.magic ()) in
                    let _140 = ref (Obj.magic (), Obj.magic ()) in
                    let _139 = ref (Obj.magic (), Obj.magic ()) in
                    let _121 = ref false in
                    (if _cl100 then
                      (_114 := (or) _110 _self_151._init115;
                       _121 := (or) !_114 _self_151._init122;
                       __last118 :=
                         (if !_121 then _102__f.S.init _103__i1 else
                           _self_151._pre119);
                       _139 := _102__f.S.step (!__last118, _105__input1)));
                    (let (_116__o, _117__s) = !_139 in
                     (if _cl100 then _self_151._pre119 <- _117__s);
                     _self_151._init122 <- (&) !_121 (not _cl100);
                     (if _cl100 then
                       (_132 := (or) !_114 _self_151._init133;
                        __last129 :=
                          (if !_132 then _116__o.S.init _104__i2 else
                            _self_151._pre130);
                        _140 := _116__o.S.step (!__last129, _106__input2)));
                     (let (_127__o, _128__s) = !_140 in
                      (if _cl100 then _self_151._pre130 <- _128__s);
                      _self_151._init133 <- (&) !_132 (not _cl100);
                      _self_151._init115 <- (&) !_114 (not _cl100); _127__o))