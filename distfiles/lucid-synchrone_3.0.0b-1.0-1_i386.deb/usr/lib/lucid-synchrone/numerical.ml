type ('a2, 'a1) _state_171 = {mutable _init157:'a2; mutable _pre156:'a1;}
and ('a2, 'a1) _state_164 = {mutable _init154:'a2; mutable _pre153:'a1;}

let deriv _cl36 _42__dt _43__dx0 _44__x _149 _self_163 =
      let _self_163 = match !_self_163 with | `St_166(_self_163) -> _self_163
                        | _ ->
                            (let _165 = {_init154 = true; _pre153 = 0.} in
                             _self_163 := `St_166(_165); _165)
                         in
      let _152 = ref false in
      let _151 = ref 0. in
      (if _cl36 then
        (_152 := (or) _149 _self_163._init154;
         _151 :=
           (if !_152 then _43__dx0 else
             (/.) ((-.) _44__x _self_163._pre153) _42__dt)));
      _self_163._init154 <- (&) !_152 (not _cl36);
      (if _cl36 then _self_163._pre153 <- _44__x); !_151

let rectangle _cl90 _93__dt _94__x0 _95__dx _150 _self_170 =
      let _self_170 = match !_self_170 with | `St_173(_self_170) -> _self_170
                        | _ ->
                            (let _172 = {_init157 = true; _pre156 = 0.} in
                             _self_170 := `St_173(_172); _172)
                         in
      let _96__x = ref 0. in
      let _155 = ref false in
      (if _cl90 then
        (_155 := (or) _150 _self_170._init157;
         _96__x :=
           (if !_155 then _94__x0 else
             (+.) _self_170._pre156 (( *. ) _95__dx _93__dt))));
      _self_170._init157 <- (&) !_155 (not _cl90);
      (if _cl90 then _self_170._pre156 <- !_96__x); !_96__x

let sinusoid _cl119 _121__f _122__dt =
      let _158 = ref 0. in
      (if _cl119 then _158 := sin (( *. ) _121__f _122__dt)); !_158

let cosinusoid _cl145 _147__f _148__dt =
      let _159 = ref 0. in
      (if _cl145 then _159 := cos (( *. ) _147__f _148__dt)); !_159