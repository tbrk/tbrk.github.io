(**************************************************************************)
(*                                                                        *)
(*  Lucid Synchrone                                                       *)
(*                                                                        *)
(*  Author : Marc Pouzet                                                  *)
(*  Organization : Demons, LRI, University of Paris-Sud, Orsay            *)
(*                                                                        *)
(**************************************************************************)

(* $Id: sampling.ml,v 1.6 2006/12/31 17:09:25 pouzet Exp $ *)

(* generic code for running sampling/event systems            *)
(* typically useful under the Graphics library                *)
(* should be compiled with "ocamlc unix.cma graphics.cma ..." *)

open Graphics

class periodic_timer =
  object
    val mutable time = 0.0
    method start = time <- Unix.gettimeofday ()
    method remaining n =
      (* the code of this function is from Xavier Leroy, November 2000 *)
      (* posted in the "Caml List" *)
      let rec delay t =
	try
	  ignore (Unix.select [] [] [] t);
	  flush stdout
	with Unix.Unix_error(Unix.EINTR, _, _) ->
	  let now = Unix.gettimeofday() in
	  let remaining = time +. n -. now in
	  if remaining > 0.0 then delay remaining in
      delay n
  end

(* run in sampling mode *)
let run_in_sampling_mode step init period =
  let timer = new periodic_timer in
  timer#start;
  timer#remaining init;
  while true do
    timer#start;
    step ();
    timer#remaining period
    done

(* this is a more conventional way using a Unix timer *)
(* semantically, it behaves as [do _ = step () when 0^init (0...1) second] *)
let periodic step init period =
  let _ = Unix.setitimer Unix.ITIMER_REAL
    { Unix.it_interval = period ; Unix.it_value = init } in
    Sys.set_signal Sys.sigalrm (Sys.Signal_handle (fun _ -> step ()))

(* the general form with input/output communication through *)
(* shared variables *)
(* [do output = step input when 0^init (0...1) second] *)
let periodic_with_inputs_outputs step init period (input, output) =
  let _ = Unix.setitimer Unix.ITIMER_REAL
    { Unix.it_interval = period ; Unix.it_value = init } in
    Sys.set_signal Sys.sigalrm 
      (Sys.Signal_handle (fun _ -> output := step !input))

(* execute a process at full speed *)
let full step (input, output) =
  while true do
    output := step !input
  done

(* asynchronous parallel composition of periodic processes *)
(* with communication through a shared variable            *)
let periodic2periodic f g default (input, output) =
  let shared = ref default in
  f (input, shared);
  g (shared, output)

let full2periodic f g default (input, output) =
  let shared = ref default in
  g (shared, output);
  f (input, shared)

(* typical runtime processes for graphical applications *)
(* we use an alternated bit and a two place buffer to synchronise *)
(* a sampled process with an event triggered one                  *)
(* Question: how to prove that the system is correct, i.e.,       *) 
(*  "no input event occurs during two sample time?                *)
(*   iff it is considered absent for the next sample time"        *)
(* is-it useful to model it in a synchronous way such that the    *)
(* following code is true by construction?                        *)

let nostatus = 
  { mouse_x = 0; mouse_y = 0; button = false;
    keypressed = false; key = ' ' }

let grun event_list init period step =
  let status0 = ref nostatus in
  let status1 = ref nostatus in
  let read_bit = ref false in
  let write_bit = ref false in
  let step () = 
    let x, y = mouse_pos () in
    if !read_bit = false then
      begin
	let status = { !status1 with mouse_x = x; mouse_y = y } in
	status1 := nostatus;
	write_bit := false;
	step status
      end
    else
      begin
	let status = { !status0 with mouse_x = x; mouse_y = y } in
	status0 := nostatus;
	write_bit := true;
	step status
      end in
  periodic step init period;
  while true do
    if !write_bit = false then
      begin
	status0 := wait_next_event event_list;
	read_bit := true
      end else
      begin
	status1 := wait_next_event event_list;
	read_bit := false
      end
  done

let sim2chro event_list init period step =
  let oc = Unix.open_process_out ("sim2chro -ecran") in
  let status0 = ref nostatus in
  let status1 = ref nostatus in
  let read_bit = ref false in
  let write_bit = ref false in
  let step oc () = 
    let x, y = mouse_pos () in
    if !read_bit = false then
      begin
	let status = { !status1 with mouse_x = x; mouse_y = y } in
	status1 := nostatus;
	write_bit := false;
	step oc status
      end
    else
      begin
	let status = { !status0 with mouse_x = x; mouse_y = y } in
	status0 := nostatus;
	write_bit := true;
	step oc status
      end in
  periodic (step oc) init period;
  while true do
    if !write_bit = false then
      begin
	status0 := wait_next_event event_list;
	read_bit := true
      end else
      begin
	status1 := wait_next_event event_list;
	read_bit := false
      end
  done

