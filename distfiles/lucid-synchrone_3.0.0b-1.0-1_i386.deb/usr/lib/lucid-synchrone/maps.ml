(**************************************************************************)
(*                                                                        *)
(*  Lucid Synchrone                                                       *)
(*                                                                        *)
(*  Author : Marc Pouzet                                                  *)
(*  Organization : Demons, LRI, University of Paris-Sud, Orsay            *)
(*                                                                        *)
(**************************************************************************)

(* $Id: $ *)

type ('a,'b) st = 
    { _memo: 'a array; _o:'b }

let map n f t =
  let alloc n f t = { } in
  let reset m = in
  let step m () = in
  alloc, reset, step

let node from n =
  let rec o = n -> pre o + 1 in
  o

let from n =
  let memo = { memo = 0; init = true } in
  let reset m = m.init <- true in
  let step ck m n =
    let o = if m.init then n else m.memo + 10 in
    m.memo <- o;
    o in
  memo, reset, step

let rec node sieve n =
  match n mod (first n) = 0 with
    true -> true fby false
  | false -> sieve n
  end


let map s res n init f t =
  (* first allocate the memory *)
  let s = match !s with
           `Map(s) -> s
          | `Snil ->
	      let memo = Array.create n (ref `Snil) in
	      let o = Array.create n init in
	      let m = { memo = memo; o = o } in
	      s := `Map(m);
	      m
    for i = 0 to n - 1 do
    s.o.(i) <- f s.memo.(i) res t.(i)
  done;
  o

let map2 s res n init f t =
  (* first allocate the memory *)
  let s = match !s with
           `Map(s) -> s
          | `Nil ->
	      let memo = Array.create n (ref `Snil) in
	      let o = Array.create n init in
	      { memo = memo;
		o = o; } in
    for i = 0 to n - 1 do
    s.o.(i) <- f s.memo.(i) res t1.(i) t2.(i)
  done;
  o

let red s res n init f t =
  (* first allocate the memory *)
  let s = match !s with
           `Map(s) -> s
          | `Nil ->
	      let memo = Array.create n Snil in
	      let o = init in
	      { memo = memo;
		o = o; } in
    let o = ref init in
    for i = 0 to n - 1 do
      o := f s.memo.(i) res !o t.(i)
    done;
    !o

let mapred s res n init1 init2 f t =
  (* first allocate the memory *)
  let s = match !s with
           `Map(s) -> s
          | `Nil ->
	      let memo = Array.create n `Snil in
	      let o = Array.create n init1 in
	      { memo = memo;
		o = o; } in
    let ofor i = 0 to n - 1 do
      let o, c = f s.o s.memo.(i) t.(i) in
      s.o <- o;
      s.c <- c
  done;
  o



