type ('key, 't) set = ('key * 't) list

let empty = []

let rec add key v s =
  match s with
      [] -> [key, v]
    | (k, w) :: s' -> 
	if key = k then (k, v) :: s' 
	else if key < k then (key, v) :: s else (k, w) :: add key v s'

let add a b = add

let rec filter f s =
  match s with
      [] -> []
    | (k, v) :: s -> if f k v then (k, v) :: filter f s else filter f s

let filter a b = filter

let rec remove key s =
  match s with
      [] -> []
    | (k, v) :: s' -> 
	if key = k then s' else if key < k then s else (k, v) :: remove key s'

let remove a b = remove
    
let map a b f s _ self =
  let self0 = match !self with `St(self) -> self | _ -> self := `St([]);[] in
  let rec maprec self s =
    match self, s with
	[], [] -> [], []
      | [], (keys, v) :: ssun ->
	  let state0 = ref `Stempty in
          let v' = f v state0 false in
	  let ks_list, s = maprec [] ssun in
          (keys, state0) :: ks_list, (keys, v') :: s
      | _, [] -> [], []
      | ((key, state) as pair) :: selfsun, (keys, v) :: ssun  ->
	  if key = keys then 
	    let v' = f v state false in
            let ks_list, s = maprec selfsun ssun in
            pair :: ks_list, (keys, v') :: s
	  else if key < keys then maprec selfsun s
	  else 
	    let state0 = ref `Stempty in
            let v' = f v state0 false in
	    let ks_list, s = maprec self ssun in
	    (keys, state0) :: ks_list, (keys, v') :: s in
  let self0, v = maprec self0 s in
  self := `St(self0); v

let red a b f acc s _ self =
  let self0 = match !self with `St(self) -> self | _ -> self := `St([]);[] in
  let rec redrec acc self s =
    match self, s with
	[], [] -> [], acc
      | [], (keys, v) :: ssun ->
	  let state0 = ref `Stempty in
          let acc = f acc v state0 false in
	  let ks_list, acc = redrec acc [] ssun in
          (keys, state0) :: ks_list, acc
      | _, [] -> [], acc
      | ((key, state) as pair) :: selfsun, (keys, v) :: ssun  ->
	  if key = keys then 
	    let acc = f acc v state false in
            let ks_list, acc = redrec acc selfsun ssun in
            pair :: ks_list, acc
	  else if key < keys then redrec acc selfsun s
	  else 
	    let state0 = ref `Stempty in
            let acc = f acc v state0 false in
	    let ks_list, acc = redrec acc self ssun in
	    (keys, state0) :: ks_list, acc in
  let self0, acc = redrec acc self0 s in
  self := `St(self0); acc

let mapred a b f acc s _ self =
  let self0 = match !self with `St(self) -> self | _ -> self := `St([]);[] in
  let rec mapredrec acc self s =
    match self, s with
	[], [] -> [], acc, []
      | [], (keys, v) :: ssun ->
	  let state0 = ref `Stempty in
          let acc, v' = f acc v state0 false in
	  let ks_list, acc, s = mapredrec acc [] ssun in
          (keys, state0) :: ks_list, acc, (keys, v') :: s
      | _, [] -> [], acc, []
      | ((key, state) as pair) :: selfsun, (keys, v) :: ssun  ->
	  if key = keys then 
	    let acc, v' = f acc v state false in
            let ks_list, acc, s = mapredrec acc selfsun ssun in
            pair :: ks_list, acc, (keys, v') :: s
	  else if key < keys then mapredrec acc selfsun s
	  else 
	    let state0 = ref `Stempty in
            let acc, v' = f acc v state0 false in
	    let ks_list, acc, s = mapredrec acc self ssun in
	    (keys, state0) :: ks_list, acc, (keys, v') :: s in
  let self0, acc, v = mapredrec acc self0 s in
  self := `St(self0); acc, v

let iter a b f s =
  let rec iterec s =
    match s with
	[] -> ()
      | (key, v) :: s -> f key v; iterec s
